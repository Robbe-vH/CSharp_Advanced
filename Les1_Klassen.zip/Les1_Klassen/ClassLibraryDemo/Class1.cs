﻿namespace ClassLibraryDemo
{
    public class House
    {
        public string Straat { get; set; }
        public int Huisnummer { get; set; }
    }
}